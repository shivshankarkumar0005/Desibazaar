# 🛍️ DesiBazaar

Flipkart/Amazon jaisi ek simple shopping marketplace website (HTML + CSS + JavaScript, no framework).

## Features
- 16 demo products, 6 categories
- Search, category filter, sorting (price / rating)
- Cart with quantity +/−, total, demo checkout
- Responsive + dark mode

## Project Structure
```
desibazaar/
├── index.html
├── css/style.css
├── js/products.js   # products data (yahan edit karein)
├── js/app.js        # cart, search, filter logic
├── README.md
└── LICENSE
```

## Run locally
`index.html` ko browser mein double-click karke khol lein. Kisi server ki zaroorat nahi.

## GitHub Pages par live karein
1. Repo push karein
2. **Settings → Pages → Branch: `main` / root → Save**
3. Site milegi: `https://<username>.github.io/<repo-name>/`

## Note
Ye demo hai: login, payment aur backend included nahi hai.

## License
MIT
