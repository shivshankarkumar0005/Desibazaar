// Products data - yahan apne products add/edit karein
const P=[
{id:1,n:"Smartphone 5G 128GB",e:"📱",c:"Mobiles",p:14999,m:18999,r:4.4},
{id:2,n:"Bluetooth Earbuds",e:"🎧",c:"Electronics",p:1299,m:2999,r:4.1},
{id:3,n:"Smart Watch",e:"⌚",c:"Electronics",p:2499,m:5999,r:4.2},
{id:4,n:"Laptop 15.6\" i5",e:"💻",c:"Electronics",p:42990,m:55990,r:4.5},
{id:5,n:"Men's Running Shoes",e:"👟",c:"Fashion",p:999,m:2499,r:4.0},
{id:6,n:"Cotton T-Shirt",e:"👕",c:"Fashion",p:349,m:799,r:4.3},
{id:7,n:"Women's Kurti",e:"👗",c:"Fashion",p:599,m:1499,r:4.2},
{id:8,n:"Backpack 30L",e:"🎒",c:"Fashion",p:699,m:1599,r:4.3},
{id:9,n:"Mixer Grinder 750W",e:"🍹",c:"Home",p:2199,m:3999,r:4.4},
{id:10,n:"Bedsheet Double",e:"🛏️",c:"Home",p:499,m:1299,r:4.1},
{id:11,n:"Study Table Lamp",e:"💡",c:"Home",p:399,m:899,r:4.0},
{id:12,n:"Cricket Bat (Kashmir Willow)",e:"🏏",c:"Sports",p:1199,m:2199,r:4.2},
{id:13,n:"Yoga Mat",e:"🧘",c:"Sports",p:449,m:999,r:4.3},
{id:14,n:"Story Book Combo",e:"📚",c:"Books",p:299,m:699,r:4.6},
{id:15,n:"Sunglasses UV400",e:"🕶️",c:"Fashion",p:499,m:1499,r:3.9},
{id:16,n:"Power Bank 20000mAh",e:"🔋",c:"Mobiles",p:1499,m:2499,r:4.3}
];
