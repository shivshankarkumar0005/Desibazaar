const cats=["All",...new Set(P.map(x=>x.c))];
let cat="All",cart={};
const $=id=>document.getElementById(id),inr=n=>"₹"+n.toLocaleString("en-IN");
function show(t){const m=$("msg");m.textContent=t;m.style.display="block";setTimeout(()=>m.style.display="none",1600)}
function draw(){
  const q=$("s").value.toLowerCase(),so=$("so").value;
  let l=P.filter(x=>(cat=="All"||x.c==cat)&&x.n.toLowerCase().includes(q));
  if(so=="l")l.sort((a,b)=>a.p-b.p);if(so=="h")l.sort((a,b)=>b.p-a.p);if(so=="r")l.sort((a,b)=>b.r-a.r);
  $("cnt").textContent=l.length+" products";
  $("g").innerHTML=l.map(x=>`<div class="p"><div class="img">${x.e}</div><h3>${x.n}</h3><span class="rt">${x.r} ★</span><div class="pr"><b>${inr(x.p)}</b><s>${inr(x.m)}</s><i>${Math.round(100-x.p/x.m*100)}% off</i></div><button class="add" data-id="${x.id}">Add to Cart</button></div>`).join("")||"<p>Kuch nahi mila 😕</p>";
  $("chips").innerHTML=cats.map(c=>`<button class="chip ${c==cat?"on":""}" data-c="${c}">${c}</button>`).join("");
}
function drawCart(){
  const ids=Object.keys(cart);let t=0,n=0;
  $("items").innerHTML=ids.map(i=>{const x=P.find(y=>y.id==i),q=cart[i];t+=x.p*q;n+=q;
    return `<div class="row"><span>${x.e}</span><div>${x.n}<br><b>${inr(x.p*q)}</b></div><span class="q"><button data-d="-1" data-id="${i}">−</button> ${q} <button data-d="1" data-id="${i}">+</button></span></div>`}).join("")||"<p style='color:var(--mut)'>Cart khali hai 🛒</p>";
  $("tot").textContent=inr(t);$("cn").textContent=n;
}
document.addEventListener("click",e=>{
  const t=e.target;
  if(t.dataset.c){cat=t.dataset.c;draw()}
  if(t.classList.contains("add")){cart[t.dataset.id]=(cart[t.dataset.id]||0)+1;drawCart();show("Cart mein add ho gaya ✅")}
  if(t.dataset.d){const i=t.dataset.id;cart[i]+=+t.dataset.d;if(cart[i]<1)delete cart[i];drawCart()}
});
$("s").oninput=draw;$("so").onchange=draw;
$("cb").onclick=()=>$("cart").classList.add("open");
$("cx").onclick=()=>$("cart").classList.remove("open");
$("buy").onclick=()=>{if(!Object.keys(cart).length)return show("Pehle kuch add karein");cart={};drawCart();$("cart").classList.remove("open");show("🎉 Order place ho gaya! (demo)")};
draw();drawCart();
